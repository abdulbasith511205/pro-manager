
// Background Particle Effect (Gen-Z Vibe)
document.addEventListener('DOMContentLoaded', () => {
    console.log("ProPredict UI Loaded ⚡");

    // Smooth Scroll for Chat
    const chatContainer = document.querySelector('.chat-container');
    if (chatContainer) chatContainer.scrollTop = chatContainer.scrollHeight;
});

// We can add more interactive vanilla JS here if needed
// e.g. Custom cursor or specialized interactions
